Disable-AzContextAutosave

Connect-AzAccount
$ResourceGroupName = "powershell grp"
$Location = "North Europe"

New-AzResourceGroup -Name $ResourceGroupName -Location $Location
