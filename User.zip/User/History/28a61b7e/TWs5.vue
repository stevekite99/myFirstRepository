<template>
  <h1>Create</h1>
</template>

<script>
export default {};
</script>

<style></style>
