<template>
  <h1>Job Details Page</h1>
</template>

<script>
export default {};
</script>

<style></style>
