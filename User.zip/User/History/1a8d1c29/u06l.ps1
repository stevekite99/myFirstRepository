$ResourceGroupName = "powershell-grp"
$Location = "north europe"
$SubnetName = "SubnetA"
$VirtualNetworkName="app-network"
$NSGName = "app-nsg"
$SubnetAddressSpace= "10.0.0.0/24"

#Create the Network Security Group rule
$SecurityRule1=New-AzNetworkSecurityRuleConfig -Name "Allow-RDP" -Description "Allow-RDP" -Access Allow -Protocol Tcp -Direction Inbound -Priority 100 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 3389

#Create the Network Security Group and apply security rule
$NSG=New-AzNetworkSecurityGroup -Name $NSGName -ResourceGroupName $ResourceGroupName -Location $Location -SecurityRules $SecurityRule1

# Get virtual network details 
$VirtualNetwork= Get-AzVirtualNetwork -Name $VirtualNetworkName -ResourceGroupName $ResourceGroupName

# Config subnet with new NSG 
Set-AzVirtualNetworkSubnetConfig -Name $SubnetName -VirtualNetwork $VirtualNetwork -NetworkSecurityGroup $NSG -AddressPrefix $SubnetAddressSpace

# Apply new subnet configs to virtual network 
$VirtualNetwork | Set-AzVirtualNetwork