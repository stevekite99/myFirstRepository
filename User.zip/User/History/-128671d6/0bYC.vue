<template>
  <h1>{{ title }}</h1>
  <p>Welcome...</p>
  <div v-if="showModal1">
    <Modal theme="sale" v-on:close="toggleModal">
      <template v-slot:links1>
        <a href="">sign up now</a>
        <a href="">more info</a>
      </template>
      <h1>Ninja Giveaway!</h1>
      <p>Grab your ninja swag for half price!</p>
    </Modal>
  </div>
  <button v-on:click="toggleModal">open modal 1</button>

  <div v-if="showModal2">
    <Modal theme="sale" v-on:close="toggleModalTwo">
      <template v-slot:links2>
        <a href="">sign up now</a>
        <a href="">more info</a>
      </template>
      <h1>Welcome to Modal2!</h1>
      <p>You are doing much better great job!</p>
    </Modal>
  </div>
  <button v-on:click="toggleModalTwo">open modal 2</button>
</template>

<script>
import Modal from "./components/Modal.vue";

export default {
  name: "App",
  components: { Modal },
  data() {
    return {
      title: "My First Vue App :)",
      header: "Sign up for the giveaway!",
      text: "Grab your ninja swag for half price!",
      showModal1: false,
      showModal2: false,
    };
  },
  methods: {
    toggleModal() {
      this.showModal1 = !this.showModal1;
    },
    toggleModalTwo() {
      this.showModal2 = !this.showModal2;
    },
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
h1 {
  border-bottom: 1px solid #ddd;
  display: inline-block;
  padding: 10px;
}
</style>
