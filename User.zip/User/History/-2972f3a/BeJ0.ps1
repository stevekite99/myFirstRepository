$AccountName = "appstore1234512321"
$AccountKind = "StorageV2"
$AccountSKU = "Standard_LRS"
$ResourceGroupName = "powershell-grp"
$Location = "Northern Europe"

# Check for the existance of the storage account 
if(Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName) {
    'Storage account already exists'
    $StorageAccount=Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName
} 
else {
    'Creating the storage accouint'
    $StorageAccount = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $AccountName -Location $Location -Kind ` $AccountKind -SkuName $AccountSKU
}

if(Get-AzStorageContainer)

$ContainerName = "data"

$StorageAccount = Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName

New-AzStorageContainer -Name $ContainerName -Context $StorageAccount.Context -Permission Blob

# Upload file as blob object into container
$BlobObject=@{
    FileLocation=".\sample.txt"
    ObjectName=".\sample.txt"
}

Set-AzStorageBlobContent -Context $StorageAccount.Context -Container $ContainerName -File $BlobObject.FileLocation -Blob $BlobObject.ObjectName