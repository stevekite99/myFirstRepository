
$ResourceGroupName = "powershell-grp"
$Location = "North Europe"

$AppId="92fafff4-20fc-4d5f-a611-7f47e2421364"
$AppSecret="e0d8Q~y2OTNVM8sZKpb7ZtG7c0-wZUtnJjNC2cyX"
$TenantID = "72908da8-542d-4dc7-9497-78b6356f22aa"
$SecureSecret = $AppSecret | ConvertTo-SecureString -AsPlainText -Force

$Credential = New-Object -TypeName System.Management.Automation.PSCredential `
-ArgumentList $AppId, $SecureSecret

Connect-AzAccount -ServicePrincipal -Credential $Credential -Tenant $TenantID
New-AzResourceGroup -Name $ResourceGroupName -Location $Location