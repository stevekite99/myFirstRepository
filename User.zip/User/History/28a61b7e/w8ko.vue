<template>
  <div class="create">
    <form>
      <label>Title:</label>
      <input v-model="title" type="text" required />
      <label>Conent:</label>
      <textarea v-model="body" require></textarea>
      <label>Tags (hit enter to add a tag)</label>
      <input type="text" />
      <button>Add Post</button>
    </form>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
