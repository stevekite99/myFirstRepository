'use strict';


let score0El = document.querySelector('#score--0'); 
let score1El = document.getElementById('score--1');

score0El.textContent = 0;
score1El.textContent = 0;

dice.classList.add('.hidden'); 
