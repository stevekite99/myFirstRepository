<template>
  <div class="create">
    <form>
      <label>Title:</label>
      <input v-model="title" type="text" required />
      <label>Conent:</label>
      <textarea v-model="body" require></textarea>
      <label>Tags (hit enter to add a tag)</label>
      <input v-model="tag" type="text" />
      <button>Add Post</button>
    </form>
  </div>
</template>
import { ref } from 'vue'
<script>
export default {
  setup() {
    const title = ref("");
    const body = ref("");
    const tag = ref("");
  },
};
</script>

<style></style>
