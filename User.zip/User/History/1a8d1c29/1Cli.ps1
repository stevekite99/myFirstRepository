$ResourceGroupName = "powershell-grp"
$Location = "north europe"
$SubnetName = "SubnetA"
$NSGName = "app-nsg"