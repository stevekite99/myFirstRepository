$ResourceGroupName = "powershell-grp"
$Location = "north europe"
$SubnetName = "SubnetA"
$VirtualNetworkName="app-network"
$NSGName = "app-nsg"

# Create the Network Security Group rule

$SecurityRule1=New-AzNetworkSecurityRuleConfig -Name "Allow-RDP" -Description "Allow-RDP" -Access Allow -Protocol Tcp -Direction Inbound -Priority 100 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 3389

$NSG=New-AzNetworkSecurityGroup -Name $NSGName -ResourceGroupName $ResourceGroupName -Location $Location -SecurityRules $SecurityRule1

$VirtualNetwork= Get-AzVirtualNetwork -Name $VirtualNetworkName -ResourceGroupName $ResourceGroupName

$Subnet = Get-AzVirtualNetworkSubnetConfig -Name $SubnetName -VirtualNetwork $VirtualNetwork

Set-AzVirtualNetworkSubnetConfig -Name $SubnetName