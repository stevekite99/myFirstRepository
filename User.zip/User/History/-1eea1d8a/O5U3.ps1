$AccountName = "appstore1234512321"
$ResourceGroupName = "powershell-grp"

# First create the container
$ContainerName = "data"

$StorageAccount = Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName

New-AzStorageContainer -Name $ContainerName -Context $StorageAccount.Context -Permission Blob

# Upload file as blob object into container
$BlobObject=@{
    FileLocation=".\sample.txt"
    ObjectName=".\sample.txt"
}

Set-AzStorageBlobContent -Context $StorageAccount.Context -Container $ContainerName -File $BlobObject.FileLocation -Blob $BlobObject.ObjectName