
$ResourceGroupName = "powershell-grp"
Remove-AzResourceGroup $ResourceGroupName -Force
'Removed Resource Grouo ' + $ResourceGroupName