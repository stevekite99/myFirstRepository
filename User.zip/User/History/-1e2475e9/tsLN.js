/*
const country = 'Germany';
const continent = 'Europe';
let population = 89;
let finlandPopulation = 6;
let averageCountry = 33;
const language = 'Deutsch';
let description1 = `${country} is in ${continent} and its ${population} million people speak ${language}`;
const isIsland = true;
console.log(population > finlandPopulation);
console.log(population < averageCountry);
console.log(isIsland, country, population, language);
console.log(description1);
if (population > 33) {
    console.log(`${country}'s population is ${population - averageCountry} million above average.`)
} else {
    console.log(`${country}'s population is ${population - germanyPopulation} million below average`)
}

if (language === 'English' && population < 50 && !isIsland) {
    console.log(`You should live in ${country}!`)
} else {
    console.log(`${country} does not meet your criteria 😢`)
}
const numNeighbors = Number(prompt('How many neighbor countries does your country have?'))
if (numNeighbors === 1) {
    console.log('Only 1 border!')
} else if (numNeighbors > 1) {
    console.log("More than 1 border")
} else {
    console.log("No borders")
}


const hasDriversLicense = true;
const hasGoodVision = true;

// if (hasDriversLicense && hasGoodVision) {
//     console.log("Sarah is able to drive!")
// } else {
//     console.log("Someone else should drive...")
// }

const isTired = false;

if (hasDriversLicense && hasGoodVision && !isTired) {
    console.log("Sarah is able to drive!")
} else {
    console.log("Someone else should drive...")
}
*/

const day = 'saturday';

switch (day) {
    case 'monday':
        console.log('Plan my course structure');
        console.log('Go to coding meetup');
        break;
    case 'tuesday':
        console.log('Prepare theory videos');
        break;
    case 'wednesday':
    case 'thursday':
        console.log('Write code examples');
        break;
    case 'friday':
        console.log('Record videos');
        break;
    case 'saturday':
    case 'sunday':
        console.log('Enjoy the weekend');
        break;
    default:
        console.log('Not a valid day!')
}

if (day === 'monday') {
    console.log('Plan my course structure')
    console.log('Go to coding meetup')
} else if (day === 'tuesday') {
    console.log('Prepare theory videos')
} else if (day === 'wednesday' || day === 'thursday') {
    console.log('Write code examples')
} else if (day === 'friday') {
    console.log('Record videos')
} else if (day === 'saturday' || day === 'sunday') {
    console.log('Enjoy the weekend!')
} else {
    console.log('Not a valid day')
}

