
$ResourceGroupName = "powershell-grp"
Remove-AzResourceGroup $ResourceGroupName -Force
'Removed Resource Group ' + $ResourceGroupName

$Location = "North Europe"
$ResourceGroup=New-AzResourceGroup -Name $ResourceGroupName -Location $Location # store ouput

'Provisioning State ' + $ResourceGroup.ProvisioningState

#Display output of ResourceGroup when created
$ResourceGroup 

$ResourceGroupExisting=Get-AzResourceGroup -Name $ResourceGroupName

$ResourceGroupExisting

$AllResourceGroups=Get-AzResourceGroup

foreach($Group in $AllResourceGroups) {
    'Removing Resource Group ' + $Group.ResourceGroupName
    Remove-AzResourceGroup -Name $Group.ResourceGroupName -Force
}


