
const country = 'Germany';
const continent = 'Europe';
let population = 49;
let finlandPopulation = 6;
let averageCountry = 33;
const language = 'English';
let description1 = `${country} is in ${continent} and its ${population} million people speak ${language}`;
const isIsland = false;
population++;
console.log(population > finlandPopulation);
console.log(population < averageCountry);
console.log(isIsland, country, population, language);
console.log(description1);
if (population > 33) {
    console.log(`${country}'s population is ${population - averageCountry} million above average.`)
} else {
    console.log(`${country}'s population is ${population - germanyPopulation} million below average`)
}

if (language === 'English' && population < 50 && !isIsland) {
    console.log(`You should live in ${country}!`)
} else {
    console.log(`${country} does not meet your criteria 😢`)
}
// const numNeighbors = Number(prompt('How many neighbor countries does your country have?'))
// if (numNeighbors === 1) {
//     console.log('Only 1 border!')
// } else if (numNeighbors > 1) {
//     console.log("More than 1 border")
// } else {
//     console.log("No borders")
// }


// const hasDriversLicense = true;
// const hasGoodVision = true;

// // if (hasDriversLicense && hasGoodVision) {
// //     console.log("Sarah is able to drive!")
// // } else {
// //     console.log("Someone else should drive...")
// // }

// const isTired = false;

// if (hasDriversLicense && hasGoodVision && !isTired) {
//     console.log("Sarah is able to drive!")
// } else {
//     console.log("Someone else should drive...")
// }
