'use strict';


let score0 = document.querySelector('score--0').textContent 
let score1 = document.querySelector('score--1').