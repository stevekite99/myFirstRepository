'use strict';

// prettier-ignore
const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const form = document.querySelector('.form');
const containerWorkouts = document.querySelector('.workouts');
const inputType = document.querySelector('.form__input--type');
const inputDistance = document.querySelector('.form__input--distance');
const inputDuration = document.querySelector('.form__input--duration');
const inputCadence = document.querySelector('.form__input--cadence');
const inputElevation = document.querySelector('.form__input--elevation');

let map; //creating global variable of map to be used within multiple functions/event handler 
let mapEvent;

if(navigator.geolocation)
navigator.geolocation.getCurrentPosition(function (pos) { //takes two callback functions (one success, one fail)
    //need to take coords out of object 
    const {latitude} = pos.coords //use destructuring to create variable w/ latitude property of coords object
    const {longitude} = pos.coords
    console.log(`https://www.google.pt/maps/@${latitude},${longitude}`); //centering map on current location
    
    const coords = [latitude, longitude] //creating array to put into leaflet setView method

    //Inserting Leaftlet map template
    map = L.map('map').setView(coords, 13); //L is leaflet namespace functin w/ methods, number is zoom value 
    //console.log(map); 

    L.tileLayer('https://tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    map.on('click', function(mapE) { //on method is from leaflet library. Handles clicks on map
        mapEvent = mapE;
        form.classList.remove('hidden')
        inputDistance.focus() //sets cursor to this field immediately 

   

      
    }) 
    

}, function () { 
    alert(`Could not get your position`)
}); 

form.addEventListener('submit', function (e) { //will display marker with input information usinf submit key
    e.preventDefault()
    inputDistance.value = inputDuration.value = inputCadence.value = inputElevation.value = ''; //clearing the input fields
    const {lat, lng} = mapEvent.latlng //using destructuring to get the lat and lng of object when clicking on map
    //code that adds the marker to the map
    L.marker([lat, lng]).addTo(map).bindPopup(L.popup({ //popup is leaflet object 
        maxWidth: 250,
        minWidth: 100,
        autoClose: false, //so marker stays on when you click to new spot 
        closeOnClick: false,
        className: 'running-popup', //assigning CSS style to marker
    })).setPopupContent('Workout').openPopup(); //adding content to marker  
})












/*
////////////////////How to Plan a Web Project 
1. User Stories 
    - Description of the application's functionality from the user's perspective 
    - All user stories put together describe the entire application

2. Features 
    - User stories determine exact features that we need to implement to make user stories work as intended 

3. Flowchart
    - Visualize all the features 
    - What we will build 

4. Architecture
    - How are we gonna build it
    - How to organize code and what JS features do we use 
    - Give us a structure to then develop the application's functionality

////////////////////Planning the mapty project 
1. User Stories
    - As a user, I want to log my running workouts with location, distance, time, pace, and steps per/min, so I can keep a log of all of my running
    - As a user I want to log my cycling workouts with location, distance, time, speed, and elevation gain, so I can keep a log of all of my cycling
    - As a user, I want to see all my workouts at a glance, so I can easily track my progress over time 
    - As a user, I want to also see my workouts on a map, so I can easily check where I work out the most
    - As a user, I want to see all my workouts when I leave the app and come back later, so that I can keep using the app over time

2. Features
    a. 
        - Map where the user clicks to add new workout (best way to get location coordinates)
        - Use geolocation to display map at current location (more user friendly)
        - Form to input distance, time, pace, steps/min (cadence)
    b.
        - Form to input distance, time speed, elevation gain  
        - Display workouts in a list 
        - Display all workouts on the map
        - Store workout data in browser using local storage API
        - On page load, read the saved data from local storage and display

3. Flowchart 
    - Contain the features we should implmenet 
    - How the different parts of the app will interact with each other 
    - Which event makes sense to implement and how dta flows across the application 

4. Architecture
    - Start coding! 
*/