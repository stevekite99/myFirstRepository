<template>
  <div class="backdrop">
    <div class="modal">
      <p>modal content</p>
    </div>
  </div>
  <style>
    .modal {
        width: 400px;
        padding: 20px;
        margin: 100px auto:
        background: white;
        border-radius: 10px;
    }
  </style>
</template>
