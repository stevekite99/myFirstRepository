
$ResourceGroupName = "powershell-grp"
Remove-AzResourceGroup $ResourceGroupName -Force
'Removed Resource Group ' + $ResourceGroupName

$Location = "North Europe"
$ResourceGroup=New-AzResourceGroup -Name $ResourceGroupName -Location $Location

'Provisioning State ' + $ResourceGroup.ProvisioningState

$ResourceGroup