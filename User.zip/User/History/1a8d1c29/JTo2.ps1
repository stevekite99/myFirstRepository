$ResourceGroupName = "powershell-grp"
$Location = "north europe"

$NSGName = "app-nsg"