$ResourceGroupName = "powershell-grp"
$VirtualNetworkName="app-network"
$VirtualNetwork = Get-AzVirtualNetwork -ResourceGroupName $ResourceGroupName -Name $VirtualNetworkName