<template>
  <div class="create">
    <form>
      <label>Title:</label>
      <input type="text" required />
      <label>Conent:</label>
      <textarea require></textarea>
      <label>Tags (hit enter to add a tag)</label>
      <input type="text" />
    </form>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
