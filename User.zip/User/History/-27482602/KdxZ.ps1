$ResourceGroupName = "powershell-grp"
$VirtualNetworkName="app-network"
$VirtualNetork = Get-AzVirtualNetwork -ResourceGroupName $ResourceGroupName -Name $VirtualNetworkName