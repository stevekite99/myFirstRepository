'use strict';


let score0El = document.querySelector('#score--0'); 
let score1El = document.getElementById('score--1');

score0El = 0;
score1El = 0;
