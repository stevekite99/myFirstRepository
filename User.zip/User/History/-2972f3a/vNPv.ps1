$AccountName = "appstore1234512321"
$AccountKind = "StorageV2"
$AccountSKU = "Standard_LRS"
$ResourceGroupName = "powershell-grp"
$Location = "Northern Europe"

# Check for 
$StorageAccount = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $AccountName -Location $Location -Kind ` $AccountKind -SkuName $AccountSKU

$ContainerName = "data"

$StorageAccount = Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName

New-AzStorageContainer -Name $ContainerName -Context $StorageAccount.Context -Permission Blob

# Upload file as blob object into container
$BlobObject=@{
    FileLocation=".\sample.txt"
    ObjectName=".\sample.txt"
}

Set-AzStorageBlobContent -Context $StorageAccount.Context -Container $ContainerName -File $BlobObject.FileLocation -Blob $BlobObject.ObjectName