'use strict';

// prettier-ignore
const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const form = document.querySelector('.form');
const containerWorkouts = document.querySelector('.workouts');
const inputType = document.querySelector('.form__input--type');
const inputDistance = document.querySelector('.form__input--distance');
const inputDuration = document.querySelector('.form__input--duration');
const inputCadence = document.querySelector('.form__input--cadence');
const inputElevation = document.querySelector('.form__input--elevation');

// let map; creating global variable of map to be used within multiple functions/event handler 
// let mapEvent;

class Workout {
    date = new Date(); //need this field for each object
    id = (Date.now() + '').slice(-10) //creating unique idea by using current timestamp and converting to string and taking last 10

    constructor(coords, distance, duration) { //these parameters are what cycling and running have in common so they can inheirt them
    this.coords = coords; //array of [lat and lng]
    this.distance = distance //in kilometers
    this.duration = duration //in minutes
    }
}

class Running extends Workout {
    constructor(coords, distance, duration, cadence) {
        super(coords, distance, duration) //initalizing the 'this' keyword in this so we can set this.cadence property for running
        this.cadence = cadence
        this._calcPace()
    }

    _calcPace() { // min/km
        this.pace = this.duration / this.distance
        return this.pace 
    }
}

class Cycling extends Workout {
    constructor(coords, distance, duration, elevationGain) {
        super(coords, distance, duration) //initalizing the 'this' keyword in this so we can set this.cadence property for running
        this.elevationGain = elevationGain
        this._calcSpeed()
    }

    _calcSpeed() {
        this.speed = this.distance / (this.duration / 60)
        return this.speed
    }
}

// const run1 = new Running([39, -12], 5.2, 24, 178)
// const cyc1 = new Cycling([39, -12], 27, 95, 523)
// console.log(run1);
// console.log(cyc1);

class App {
    //setting private properties on all the instances created on App class 
    #map;
    #mapEvent;
    constructor() {
        this._getPosition() //calling geolocation api 
        form.addEventListener('submit', this._newWorkout.bind(this)) //will display marker with input information using submit key. Using bind here because the 'this' keyword in an event listener will always point to the element of that listener (form in this case) and not to the App object which we need here. So we have to bind this to App. 
        inputType.addEventListener('change', this._toggleElevationField) //use change event when using a drop down menu 
            
        
        
    }

    _getPosition() {
    if(navigator.geolocation)
    navigator.geolocation.getCurrentPosition(this._loadMap.bind(this), function () {  //takes two callback functions (one success, one fail). Making this defined using bind method
    alert(`Could not get your position`)
}); 
    }

    _loadMap(pos) {
        //need to take coords out of object 
    const {latitude} = pos.coords //use destructuring to create variable w/ latitude property of coords object
    const {longitude} = pos.coords
    console.log(`https://www.google.pt/maps/@${latitude},${longitude}`); //centering map on current location
    
    const coords = [latitude, longitude] //creating array to put into leaflet setView method

    //Inserting Leaftlet map template
    this.#map = L.map('map').setView(coords, 13); //L is leaflet namespace functin w/ methods, number is zoom value 
    //console.log(map); 

    L.tileLayer('https://tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(this.#map);

    this.#map.on('click', this._showForm.bind(this))  //on method is from leaflet library. Handles clicks on map. 'this' keyword is pointing to map event handler and not to object App so we need to bind here as well 
    }

    _showForm(mapE) {
        this.#mapEvent = mapE;
        form.classList.remove('hidden')
        inputDistance.focus() //sets cursor to this field immediately  
    }

    _toggleElevationField() {
        inputElevation.closest('.form__row').classList.toggle('form__row--hidden') //closest method needs full element name with '.'
        inputCadence.closest('.form__row').classList.toggle('form__row--hidden') //making one field visible or not with toggle method
    }

    _newWorkout(e) {
        e.preventDefault()
        inputDistance.value = inputDuration.value = inputCadence.value = inputElevation.value = ''; //clearing the input fields
        const {lat, lng} = this.#mapEvent.latlng //using destructuring to get the lat and lng of object when clicking on map
        //code that adds the marker to the map
        L.marker([lat, lng]).addTo(this.#map).bindPopup(L.popup({ //popup is leaflet object 
            maxWidth: 250,
            minWidth: 100,
            autoClose: false, //so marker stays on when you click to new spot 
            closeOnClick: false,
            className: 'running-popup', //assigning CSS style to marker
        })).setPopupContent('Workout').openPopup(); //adding content to marker  
    }


}

const app = new App(); //creating an object or instance of the App class 













/*
////////////////////How to Plan a Web Project 
1. User Stories 
    - Description of the application's functionality from the user's perspective 
    - All user stories put together describe the entire application

2. Features 
    - User stories determine exact features that we need to implement to make user stories work as intended 

3. Flowchart
    - Visualize all the features 
    - What we will build 

4. Architecture
    - How are we gonna build it
    - How to organize code and what JS features do we use 
    - Give us a structure to then develop the application's functionality

////////////////////Planning the mapty project 
1. User Stories
    - As a user, I want to log my running workouts with location, distance, time, pace, and steps per/min, so I can keep a log of all of my running
    - As a user I want to log my cycling workouts with location, distance, time, speed, and elevation gain, so I can keep a log of all of my cycling
    - As a user, I want to see all my workouts at a glance, so I can easily track my progress over time 
    - As a user, I want to also see my workouts on a map, so I can easily check where I work out the most
    - As a user, I want to see all my workouts when I leave the app and come back later, so that I can keep using the app over time

2. Features
    a. 
        - Map where the user clicks to add new workout (best way to get location coordinates)
        - Use geolocation to display map at current location (more user friendly)
        - Form to input distance, time, pace, steps/min (cadence)
    b.
        - Form to input distance, time speed, elevation gain  
        - Display workouts in a list 
        - Display all workouts on the map
        - Store workout data in browser using local storage API
        - On page load, read the saved data from local storage and display

3. Flowchart 
    - Contain the features we should implmenet 
    - How the different parts of the app will interact with each other 
    - Which event makes sense to implement and how dta flows across the application 

4. Architecture
    - Start coding! 
*/