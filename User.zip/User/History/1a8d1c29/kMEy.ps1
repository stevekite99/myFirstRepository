$ResourceGroupName = "powershell-grp"
$Location = "north europe"
$SubnetName = "SubnetA"
$NSGName = "app-nsg"

# Create the Network Security Group rule

New-AzNetworkSecurityRuleConfig -Name "Allow-RDP" -Description "Allow-RDP" -Access Allow -Protocol 