/*
const country = 'Germany';
const continent = 'Europe';
let germanyPopulation = 100;
let finlandPopulation = 6;
let averageCountry = 33;
const language = 'Deutsch';
let description1 = `${country} is in ${continent} and its ${germanyPopulation} million people speak ${language}`;
const isIsland = false;
germanyPopulation++;
console.log(germanyPopulation > finlandPopulation);
console.log(germanyPopulation < averageCountry);
console.log(isIsland, country, germanyPopulation, language);
console.log(description1);
if (germanyPopulation > 33) {
    console.log(`${country}'s population is ${germanyPopulation - averageCountry} million above average.`)
} else {
    console.log(`${country}'s population is ${averageCountry - germanyPopulation} million below average`)
}
const numNeighbors = Number(prompt('How many neighbor countries does your country have?'))
if (numNeighbors === 1) {
    console.log('Only 1 border!')
} else if (numNeighbors > 1) {
    console.log("More than 1 border")
} else {
    console.log("No borders")
}
*/

const hasDriversLicense = true;
const hasGoodVision = false;

console.log(hasDriversLicense && hasGoodVision);
console.log(hasDriversLicense || hasGoodVision);
console.log(!hasDriversLicense);


if (hasDriversLicense && hasGoodVision) {
    console.log("Sarah is able to drive")
} else {
    console.log("Someone else should drive...")
}

