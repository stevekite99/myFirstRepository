
const country = 'Germany';
const continent = 'Europe';
let germanyPopulation = 100;
let finlandPopulation = 6;
let averageCountry = 33;
const language = 'Deutsch';
let description1 = `${country} is in ${continent} and its ${germanyPopulation} million people speak ${language}`;
const isIsland = false;
germanyPopulation++;
console.log(germanyPopulation > finlandPopulation);
console.log(germanyPopulation < averageCountry);
console.log(isIsland, country, germanyPopulation, language);
console.log(description1);
if (germanyPopulation > 33) {
    console.log(`${country}'s population is ${germanyPopulation - averageCountry} million above average.`)
} else {
    console.log(`${country}'s population is ${averageCountry - germanyPopulation} million below average`)
}
const numNeighbors = Number(prompt('How many neighbor countries does your country have?'))
if (numNeighbors === 1) {
    console.log('Only 1 border!')
} else if (numNeighbors > 1) {
    console.log("More than 1 border")
} else {
    console.log("No borders")
}



/*
const favorite = Number(prompt('What is your favorite number?'));

if (favorite === 23) {
    console.log(`Cool! 23 is an amazing number!`);
} else if (favorite === 7) {
    console.log(`7 is also a cool number`);
} else if (favorite === 9) {
    console.log(`9 is also a cool number`);
} else {
    console.log('Number is not 23 or 7 or 9')
}

if (favorite !== 23) console.log("Why not 23?");
*/
