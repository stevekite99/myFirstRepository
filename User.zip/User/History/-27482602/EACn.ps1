$ResourceGroupName = "powershell-grp"
$VirtualNetworkName="app-network"
$VirtualNetwork = Get-AzVirtualNetwork -ResourceGroupName $ResourceGroupName -Name $VirtualNetworkName

$SubnetConfig = $VirtualNetwork | Get-AzVirtualNetworkSubnetConfig

foreach ($Subnet in $SubnetConfig) {
'The Subnet name is ' + $Subnet.Name
'The Subnet IP Address Prefix is' + $Subnet.AddressPrefix
}