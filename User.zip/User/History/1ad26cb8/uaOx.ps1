$VirtualNetworkName="app-network"
$SubnetName = "SubnetA"