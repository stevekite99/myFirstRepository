$AccountName = "appstore1234512321"
$AccountKind = "StorageV2"
$AccountSKU = "Standard_LRS"
$ResourceGroupName = "powershell-grp"
$Location = "Northern Europe"

# Check for the existance of the storage account 
if(Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName) {
    'Storage account already exists'
    $StorageAccount=Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName
} 
else {
    'Creating the storage account'
    $StorageAccount = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $AccountName -Location $Location -Kind ` $AccountKind -SkuName $AccountSKU
}

$ContainerName = "data"

if(Get-AzStorageContainer -Name $ContainerName -Context $StorageAccount.Context) {
    'Container already exists'
    $Container= -Name $ContainerName -Context $StorageAccount.Context
} else {
    'Creating container'
    $Container=New-AzStorageContainer -Name $ContainerName -Context $StorageAccount.Context -Permission Blob
}



# Upload file as blob object into container
$BlobObject=@{
    FileLocation=".\sample.txt"
    ObjectName=".\sample.txt"
}

if(Get-AzStorageBlob -Context $StorageAccount.Context -Container $ContainerName -Blob $BlobObject.ObjectName) {
    'Blob already exists'
    $Blob=Get-AzStorageBlob -Context $StorageAccount.Context -Container $ContainerName -Blob $BlobObject.ObjectName
} else {
    'Creating the blob'
    Set-AzStorageBlobContent -Context $StorageAccount.Context -Container $ContainerName -File $BlobObject.FileLocation -Blob $BlobObject.ObjectName
}
