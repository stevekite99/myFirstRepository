$AccountName = "appstore1234512321"
$ResourceGroupName = "powershell-grp"

# First create the container
$ContainerName = "data"

$StorageAccount = Get-AzStorageAccount -Name $AccountName -ResourceGroupName $ResourceGroupName

New-AzStorageContainer -Name $ContainerName -Context $StorageAccount.Context -Permission Blob